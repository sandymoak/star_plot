
# coding: utf-8

# In[2]:

import matplotlib.pyplot as plt
import numpy as np
import pylab

#load in star data sample 1
x = np.loadtxt('star_plot/Periods.txt', delimiter = ',', unpack = True)
y = np.loadtxt('star_plot/Mbs.txt',  delimiter = ',', unpack = True)

#load in star data sample 2
a, b = np.loadtxt('star_plot/Period and Mb.txt', delimiter = ',', unpack = True)

#plot star data and define axis
plt.plot(x, y, 'b*')
plt.plot(a, b, 'r*')
plt.axis([0.4000000, 1.8000000, -1.5000000, -5.5000000])

#best fit line
z = np.polyfit(x, y, 1)
f = np.poly1d(z)
plt.plot(x,f(x),"g-")

#label axis
plt.xlabel('log P (days)')
plt.ylabel('Mb (abs magnitude)')

#legend
pylab.plot(x, y, 'b*', label='sample 1')
pylab.plot(a, b, 'r*', label='sample 2')
pylab.plot(z, f, 'g-', label='best fit')
pylab.legend(loc='upper left')

#print your plot
plt.show()


# In[ ]:



